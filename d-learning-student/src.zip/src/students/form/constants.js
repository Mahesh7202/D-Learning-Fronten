export const Branch = [
    {
        value: 'br',
        label: 'CSE',
      },
      
    
];

export const Department = [
    {
        value: 'de',
        label: 'CSE',
      },
     
    
];

export const SemNo = [
    {
        value: 'se',
        label: 'CSE',
      },
      
    
]